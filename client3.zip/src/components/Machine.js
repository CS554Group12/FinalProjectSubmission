import React, { Component } from 'react';
import axios from 'axios';
import noImage from '../img/download.jpeg';

import '../App.css';

import { Player } from 'video-react';
import "../../node_modules/video-react/dist/video-react.css";


class Machine extends Component {
   constructor(props) {
      super(props);
      this.state = {
         data: undefined,
         loading: false
      };
   }
   componentWillMount() {
      this.getShow();
   }
   async getShow() {
      this.setState({
         loading: true
      });
      try {
         const response = await axios.get(
            `http://localhost:3001/video/${this.props.match.params.id}`
         );
         console.log(response);
         this.setState({
            data: response.data,
            loading: false
         });
      } catch (e) {
         console.log(`error ${e}`);
      }
   }
   render() {
      let body = null;
      const regex = /(<([^>]+)>)/gi;
      
      if (this.state.loading) {
         body = (
            <div>
               <h1>Please Wait...</h1>
               <br />
               Loading...
            </div>
         );
      } else if (this.state.error) {
         body = (
            <div>
               <h1>{this.state.error}</h1>
            </div>
         );
      } else {
		  
		  
         body = (
		 
            <div>
               <h3 className="cap-first-letter">
                  {this.state.data && this.state.data.Key}
               </h3>
               
               <br />
               <br />
               
			   
			   		  <Player class="video-react"
      playsInline
      poster="/assets/poster.png"
      src={this.state.data["url"]} type="video/mp4"
	  fluid={false}
        width={400}
        height={400}
		marginLeft="200"
		marginRight="200"
		marginBottom="200"
		marginTop="200"

    />
	
	<br />
               <br />
               <br />
               <br />
	
	<h3 className="cap-first-letter1">
                  {this.state.data && this.state.data.description}
               </h3>
               <br />
               <br />
               <br />
               <br />
	
	</div>

			
		
         );
      }
      return body;
   }
}

export default Machine;

