import React, { Component } from 'react';
import axios from 'axios';
import { Link } from 'react-router-dom';

class MachineList extends Component {
   constructor(props) {
      super(props);
	  
	   this.searchShows = this.searchShows.bind(this);
	  
      this.state = {
         data: undefined,
         loading: false,
         searchTerm: undefined,
         searchData: undefined,
         currentLink: 'https://pokeapi.co/api/v2/machine/',
         nextLink: undefined,
         prevLink: undefined,
         offset : 0,
         limit: 0
      };
   }

   async getShows() {
      try {
         console.log(this.props.match.params.page);
         if(!this.props.match.params.page)
         {
            this.offset = 0;
            const response = await axios.get(`http://localhost:3001/recommendation/`);
            await this.setState({ data: response.data});
         }
         else
         {
            this.offset = this.props.match.params.page * 20;
            this.limit = 20;
            const response = await axios.get(`http://localhost:3001/recommendation/`);
            await this.setState({ data: response.data});
         }
      } catch (e) {
         console.log(e);
      }
   }

   async componentDidMount() {
      await this.getShows();
   }

   handleChange = (e) => {
      let value = e.target.value;
      this.setState({ currentLink: value }, () => {
         this.getShows();
      });
   }

   handleClick = (e) => {
      let value = e.target.value;
      let isChecked = e.target.checked;
      console.log(value);
      console.log(isChecked);
   }
      
   onSubmit(e) {
      e.preventDefault();
   }

   searchShows(){
      try {
         //const response = await axios.get('https://pokeapi.co/api/v2/pokemon' + this.state.searchTerm);
         const response =  axios.get(this.state.nextLink);
         this.setState({searchData: response.data, searchTerm: true});
      } catch (e) {
         console.log(e);
      }
   }
   
   render() {
      let body = null;
      let nextPage = null;
      let previousPage = null;
      let li = null;
      let nextOffset = (this.offset + 20) / 20;
      let prevOffset = (this.offset - 20) / 20;
   
      let next= null;
      let prev = null;
   
      let cnt = 0;
     
		if (this.state.data) {
		   li = 
            this.state.data && 
            this.state.data.map((shows, cnt) => {
               return(
                  <li key={shows.id}>
                     <div className="card">
                        <label for="favorite" class="favorites-btn">
                           <input type="checkbox" id="favorite" value={shows.id} onClick={this.handleClick}
                           />
                              <i class="glyphicon glyphicon-star-empty"></i>
                              <i class="glyphicon glyphicon-star"></i>
                              <span class="add-to-favorites">Add to Favorites</span>
                        </label>
			               
                        <Link to={`/recommended/${shows.id}/`}>
                           <br />
								   <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT3w6QYtXhSCXyAeOIxEzzhJVaOUmRAQSbK1TTw_EtJ4unPuda_TA" alt="Avatar" width="500px"/>
                           <div class="container">
                           <br/>
                              <h4><b>{shows.Key}</b></h4> 
                           </div>
						      </Link>
					      </div>
                  </li>
               );
            });
         
         body =  (
            <div>
               <h1>Recommended Videos</h1>
            <br />
            <br />
               <ul className="list-unstyled">{li}</ul>
         
            </div>
         );
      }
      
      return  body;
   }
}

export default MachineList;
