var uuid = require("uuid/v1");
var express = require("express");
var app = express();
var bodyParser = require("body-parser");
var dataSetObj = require("./insert");

const aws = require("aws-sdk");

const s3Bucket = "cs554netflix2";

app.use(bodyParser.json());
app.use(bodyParser.urlencoded());

var logRequestPathBodyArray = new Array();
var pathsAccessedArray = new Array();
var reqCnt = 0;  

var urlArray = new Array();

var session = {"id" : 1, "email" : "smartshree4392@gmail.com"};

async function getVideoConnection() 
{
var MongoClient = require("mongodb").MongoClient;
var conn = await MongoClient.connect("mongodb://localhost:27017/", {useNewUrlParser : true});
var db = await conn.db("cs554_Final_Project");
var coll = await db.collection("Videos");
return await coll;
}

async function getUserConnection()
{
	var MongoClient = require("mongodb").MongoClient;
	var conn = await MongoClient.connect("mongodb://localhost:27017/", {useNewUrlParser : true});
	var db = await conn.db("cs554_Final_Project");
	var coll = await db.collection("Users");
	return await coll;
}

async function getFlaskConnection()
{
	var MongoClient = require("mongodb").MongoClient;
	var conn = await MongoClient.connect("mongodb://localhost:27017/", {useNewUrlParser : true});
	var db = await conn.db("cs554_Final_Project");
	var coll = await db.collection("DataSet");
	return await coll;
}

async function fetchS3Database()
{
	let flaskDataSet = await getFlaskConnection(); 
	let addDataSetStatus = await addDataSet();
	let isBucket = await checkIfBucketPresent();
	
	if(await addDataSetStatus && !await isBucket)
	{
		try { 
			let dbUsers = await getUserConnection();
			await dbUsers.insertOne({id : 1, "FavoriteVideos" : [], "RecommendedVideos" : []});
			
			let videoObj = new Object();
			let cnt = 0;
			let dbVideo = await getVideoConnection();
			
			aws.config.setPromisesDependency();
			aws.config.update({
				accessKeyId: "",
				secretAccessKey: "",
				region: 'us-east-1',
				signatureVersion: 'v4'
			});
		
			var signedUrl = new Object();
			var response = new Object();
			var s3 = new aws.S3();
			response = await s3.listObjectsV2({		// Uncomment when you use aws
				Bucket: s3Bucket
			}).promise();
		 
			for(let i=0; i<await response.Contents.length; i++)
			{
				let newKey = await response.Contents[i].Key; 
				params = {Bucket:s3Bucket, Key: await newKey, Expires: 200000};

				// uncomment when you use aws
				const url = await s3.getSignedUrl('getObject', params);
				
				response.Contents[i]["url"] = await url;
				response.Contents[i]["id"] = uuid();
			
				let tempKey = await response.Contents[i].Key;
				 
				tempKey = await tempKey.slice(0, tempKey.length-4);
				
				response.Contents[i].Key = await tempKey; 

				console.log(await url);
				videoObj[cnt] = await url;
				await cnt++; 
			}
		
			for(let i=0; i<await response.Contents.length; i++) 
			{
				for(let j=0; j< await dataSetObj["dataSetArr"].length; j++)
				{
					if(await response.Contents[i].Key == await dataSetObj["dataSetArr"][j].Name.replace([":"], "") || await response.Contents[i].Key == await dataSetObj["dataSetArr"][j].Name.replace([","], ""))
					{
						response.Contents[i]["id"] = await dataSetObj["dataSetArr"][j]["id"];
						response.Contents[i]["Genre"] = await dataSetObj["dataSetArr"][j]["Genre"]; 
					}
				}
			}
		
			await dbVideo.insertOne(await response);									// need to uncomment when we use AWS S3
			
			await addVideoToFavorite(1, "2");
			await addVideoToRecommendations(1, "2");  
		}
		catch(e)
		{
			console.log(e);
		}
	}	
}

async function addDataSet()
{
	let flaskDataSet = await getFlaskConnection(); 
	let insertStatus;
	let checkIfAlreadyPresent = await flaskDataSet.findOne({id : 1}); 
	//console.log(await flaskDataSet.findOne({id : 1})); 
	
	if(await checkIfAlreadyPresent)
	{
		return true;
	}
	else
	{
		insertStatus = await flaskDataSet.insertOne(await dataSetObj);
	}
	
	if(await insertStatus)
	{
		return true;
	}
	else
	{
		return false;
	}	
}

async function getFavoritedVideos(userId)
{
	let dbUser = await getUserConnection();
	let UserObject = await dbUser.findOne({"id" : await userId});
	
	if(await UserObject)
	{
		var favoriteVideoArr = await UserObject["FavoriteVideos"];
	}
	
	return await favoriteVideoArr;
}

async function getAllVideos()
{
	let dbVideo = await getVideoConnection();
	let AllVideosObj = await dbVideo.findOne({"Name" : s3Bucket});
	let AllVideosArr = await AllVideosObj["Contents"];
	
	return await AllVideosArr;
}

async function checkIfBucketPresent()
{
	let dbVideo = await getVideoConnection();
	let isPresent = await dbVideo.findOne({"Name" : s3Bucket});
	
	if(await isPresent)
	{
		return true;
	}
	else
	{
		return false;
	}
}

async function getVideoById(videoId)
{
	let dbVideo = await getVideoConnection();
	let SingleVideosObj = await dbVideo.findOne({"Name" : s3Bucket});
	let SingleVideosArr = await SingleVideosObj["Contents"];
	
	for(let i=0; i<SingleVideosArr.length; i++)
	{
		if(SingleVideosArr[i].id == videoId)
		{
			var finalSingleObj = await SingleVideosArr[i]; 
		}
	}
	console.log(await finalSingleObj);
	
	return await finalSingleObj;
}

async function addVideoToFavorite(userId, videoId)
{
	let dbVideo = await getVideoConnection();
	let dbUser = await getUserConnection();
	let videoObj = await getVideoById(videoId);

	if(await videoObj)
	{
		var addToFavStatus = await dbUser.updateOne({"id" : userId}, {$push : {"FavoriteVideos": await videoObj}});
	}
	
	if(await addToFavStatus)
	{
		return true;
	}
	else
	{
		return false;
	}
};

async function removeVideoFromFavorite(userId, videoId) {
	let dbVideo = await getVideoConnection();
	let dbUser = await getUserConnection();
	let videoObj = await getVideoById(videoId);

	if(await videoObj)
	{
		var removeFromFavStatus = await dbUser.updateOne({"id" : userId}, {$pull : {"FavoriteVideos": await videoObj}});
	}
	
	if(await removeFromFavStatus)
	{
		return true;
	}
	else
	{
		return false;
	}
};

async function addVideoToRecommendations(userId, videoId)
{	
	let dbUser = await getUserConnection();
	let favoritedVideoArr = new Array();
	
	await favoritedVideoArr.push(videoId);
	
	let recommendedVideoArray = ["2"];		// flask call
	let recommendedVideoObjArr = new Array();
	
	for(let i=0; i<recommendedVideoArray.length; i++)
	{
		if(await getVideoById(await recommendedVideoArray[i]))
		{
			await recommendedVideoObjArr.push(await getVideoById(recommendedVideoArray[i]));
		}
	}
		
	let updateStatus = await dbUser.updateOne({id : userId}, {$set : {"RecommendedVideos" : await recommendedVideoObjArr}});
		
	if(await updateStatus)
	{
		return true;
	}
	else
	{
		return false;
	}
	
};

app.post("/recommendation/:videoId", async function(req, res){
	
	let addRecoStatus = await addVideoToRecommendations(session.id, req.params.videoId);
	res.json(await addRecoStatus);
});

app.post("/favorites/:videoId", async function(req, res){
	
	let addFavStatus = await addVideoToFavorite(session.id, req.params.videoId);
	res.json(await addFavStatus);
	
});

app.delete("/favorites/:videoId", async function(req, res){
	
	let removeFavStatus = await removeVideoFromFavorite(session.id, req.params.videoId);
	res.json(await removeFavStatus);
	
});

async function getAllRecommendedVideos(userId)
{
	let dbUser = await getUserConnection();
	let userObj = await dbUser.findOne({"id" : await userId});
	let recommendedVideoArr = await userObj["RecommendedVideos"];
	
	return await recommendedVideoArr;
}
	
app.get("/video", async function(req, res){
	
	let videoList = await getAllVideos();
	res.json(await videoList);
});

app.get("/video/:videoId", async function(req, res){
	
	let singleVideo = await getVideoById(req.params.videoId);
	res.json(await singleVideo);
});
		

app.get("/recommendation/", async function(req, res){
	
	let userRecommendationList = await getAllRecommendedVideos(session.id);
	res.json(await userRecommendationList);
});


app.get("/favorites/",async function(req, res){
	
	let favoriteVideoList = await getFavoritedVideos(session.id);
	res.json(await favoriteVideoList );
});

app.get("/loggedUser", async function(req, res){
	
	res.json(session);
});  


app.listen("3001", async function(){
	
	await fetchS3Database();

	console.log("The server is active on localhost 3001.");
}); 
		
		
		 
		
		
		
		
		
		
		
		
		
		
		
		