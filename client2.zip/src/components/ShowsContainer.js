import React, { Component } from 'react';
import { Route, Switch } from 'react-router-dom';
import ShowList from './ShowList';
import PokeShow from './Show';
import Pokemon from './Pokemon';
import Berry from './Berry';
import BerryList from './BerryList';
import MachineList from './MachineList';
import Machine from './Machine';
import ErrorContainer from './ErrorContainer';
import DescriptionContainer from './DescriptionContainer';

class ShowsContainer extends Component {
   render() {
      return (
         <div>
            <Switch>
               <Route path="/pokemon/page/" exact component={ShowList} />
               <Route path="/pokemon/:id" exact component={PokeShow} />
			   <Route path="/pokemon/page" exact component={ShowList} /> 
			   <Route path="/berries/page/" exact component={BerryList} />
			   <Route path="/berries/page/:page" exact component={BerryList} />
			   <Route path="/berries/:id" exact component={Berry} />
			   <Route path="/machines/page/" exact component={MachineList} />
			   <Route path="/machines/page/:page" exact component={MachineList} />
			   <Route path="/machines/:id" exact component={Machine} />
			   <Route path="/" component={DescriptionContainer} />
			   <Route path="*" component={ErrorContainer} />
            </Switch>
         </div>
      );
   }
}

export default ShowsContainer;
