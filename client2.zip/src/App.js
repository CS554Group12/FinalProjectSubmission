import React, { Component } from 'react';
import logo from './img/netflix.png';
import './App.css';
import ShowsContainer from './components/ShowsContainer';
import ErrorContainer from './components/ErrorContainer';

import { BrowserRouter as Router, Route, Link } from 'react-router-dom';

class App extends Component {
   render() {
      return (
         <Router>
            <div className="App">
               <header className="App-header">
                  <img src={logo} className="App-logo" alt="logo" />
                  <h1 className="App-title">Movies</h1>
                  <Link className="showlink" to="/pokemon/page/">
                     All Videos
                  </Link>
				  
				  <Link className="showlink" to="/berries/page/0">
                     Favorites
                  </Link>
				  
				  <Link className="showlink" to="/machines/page/0">
                     Recommended Videos
                  </Link>
				  
               </header>
               <br />
               <br />
               <div className="App-body">
                 
				  
                  <Route path="/" component={ShowsContainer} />

				  
				  
               </div>
            </div>
         </Router>
      );
   }
}

export default App;
